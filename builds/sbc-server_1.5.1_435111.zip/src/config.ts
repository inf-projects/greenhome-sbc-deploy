import path from 'path';

export const IS_PRODUCTION = process.env.NODE_ENV == 'production';
export const IS_TEST = process.env.NODE_ENV == 'test';

export const SERVICE_PORT = +process.env.PORT || 5000;
export const SERVICE_NAME = 'GREEN HOME';

export const WORKING_DIR = path.resolve(process.env.WORKING_DIR);

export const PUBLIC_DIR = path.join(WORKING_DIR, 'public');
export const UPLOAD_DIR = path.join(WORKING_DIR, 'uploads');
export const CONFIG_FILE = path.join(WORKING_DIR, 'data', 'config.json');
export const MEDIA_DIR = 'media';

export const DB_PATH = IS_TEST ? `${WORKING_DIR}/data/main.test.sqlite` : `${WORKING_DIR}/data/main.sqlite`;

export const TOKEN_TTL = 365 * 24 * 60 * 60;
export const VERIFY_CODE_LENGTH = 32;
export const VERIRY_CODE_TTL = 365 * 24 * 60 * 60;

export const DATE_FORMAT = 'DD/MM/YYYY';

// const SERIAL_PORT = '/dev/ttyACM0';
export const SERIAL_PORT = process.env.SERIAL_PORT;
export const COMMAND_LENGTH = 103;
export const BLOCK_DATA_OFFSET = 3;

export const EFFECT_UPDATE_INTERVAL = 250;
export const COMMAND_SEND_INTERVAL = 100;
export const DEFINED_STATE_UPDATE_INTERVAL = 1000;

export const BLINK_DELAY = 300;
