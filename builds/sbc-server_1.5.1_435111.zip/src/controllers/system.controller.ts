import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import {
    check,
    validationResult,
    body,
    sanitizeBody,
    matchedData,
    query,
} from 'express-validator';

import { Controller } from '.';
import { Service, ControlState } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { FloorService, ControlService, SystemService } from '../services';
import { wrap } from '../lib/helper';

@injectable()
export class SystemController extends Controller {
    public readonly router = Router();
    public readonly path = '/system';

    constructor(@inject(Service.System) private systemService: SystemService) {
        super();

        this.router.get('/', wrap(this.getConfig.bind(this)));

        this.router.post('/background', wrap(this.addBackground.bind(this)));
        this.router.post('/logo', wrap(this.addLogo.bind(this)));
        this.router.post('/audio', wrap(this.addAudio.bind(this)));
        this.router.get('/audio', wrap(this.controlAudio.bind(this)));
        this.router.post('/video', wrap(this.addVideo.bind(this)));
        this.router.patch('/video/idle', wrap(this.updateIdleVideo.bind(this)));
        this.router.patch('/password', wrap(this.changePassword.bind(this)));
        this.router.patch(
            '/display-mode',
            wrap(this.changeDisplayMode.bind(this)),
        );
        // Display control routes with aligned names
        this.router.post('/show-image', wrap(this.showImage.bind(this)));
        this.router.post('/play-video', wrap(this.playVideo.bind(this)));

        logger.info('[System controller] initialized');
    }

    async getConfig(req: Request, res: Response) {
        res.composer.success(this.systemService.getConfig());
    }

    async addBackground(req: Request, res: Response) {
        res.composer.success(await this.systemService.addBackground(req));
    }

    async addLogo(req: Request, res: Response) {
        res.composer.success(await this.systemService.addLogo(req));
    }

    async addAudio(req: Request, res: Response) {
        res.composer.success(await this.systemService.addAudio(req));
    }

    async addVideo(req: Request, res: Response) {
        res.composer.success(await this.systemService.addVideo(req));
    }

    async updateIdleVideo(req: Request, res: Response) {
        res.composer.success(await this.systemService.updateIdleVideo(req));
    }

    async controlAudio(req: Request, res: Response) {
        const { action } = req.query;

        res.composer.success(
            this.systemService.controlAudio(action as 'play' | 'stop'),
        );
    }

    async changePassword(req: Request, res: Response) {
        const { password } = req.body;
        res.composer.success(await this.systemService.changePassword(password));
    }

    async changeDisplayMode(req: Request, res: Response) {
        const { mode } = req.body;
        res.composer.success(await this.systemService.changeDisplayMode(mode));
    }

    async showImage(req: Request, res: Response) {
        const { image } = req.body;
        this.systemService.showImage(image);
        res.composer.success({ status: 'displaying image' });
    }

    async playVideo(req: Request, res: Response) {
        const { video } = req.body;
        this.systemService.playVideo(video);
        res.composer.success({ status: 'playing video' });
    }
}
