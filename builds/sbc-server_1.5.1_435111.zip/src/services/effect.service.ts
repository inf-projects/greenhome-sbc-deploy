import { inject, injectable } from 'inversify';
import _ from 'lodash';
import fs from 'fs-extra';
import path from 'path';
import { In } from 'typeorm';
import * as csv from 'fast-csv';

import logger from '../lib/logger';
import { WORKING_DIR, CONFIG_FILE } from '../config';
import { Block, Floor, Apartment, Effect, EffectPhase } from '../entities';
import { ControlState, Service, OrderDirection } from '../types';
import { UploadService } from './upload.service';
import { Request } from '../lib/response-composer';

@injectable()
export class EffectService {
    constructor(
        @inject(Service.Upload) private uploadService: UploadService,
    ) {
        logger.info('[Effect service] Construct');
    }

    public async getOne(id: number) {
        const effect = await Effect.findOne({ id },
            { relations: ['block', 'phases'] });

        if (_.isEmpty(effect)) {
            throw new Error('Invalid effect id')
        }

        // TODO: optimize by sorting in database
        effect.phases = _.orderBy(effect.phases, 'sortOrder', 'asc');

        return effect;
    }

    // NOTE: add effect using file instead
    // public async addEffect(blockId: number, name: string) {
    //     const block = await Block.findOne({ id: blockId });
    //     if (!block) {
    //         throw new Error('Invalid block id');
    //     }

    //     const effect = new Effect();
    //     effect.name = name;
    //     effect.phases = [];
    //     effect.block = block;

    //     await effect.save();

    //     return 'ADDED';
    // }

    public async addEffect(req: Request) {
        const { blockId, uploadedPath } = await this.uploadService.handleOtherFile(req, `efx_block_`);

        const block = await Block.findOne({ id: blockId });
        if (!block) {
            throw new Error('Invalid block id');
        }

        const parseCSV = () => new Promise<Array<Array<number>>>(resolve => {
            let phases: Array<Array<number>> = [];
            let rowIdx = 0;

            fs.createReadStream(uploadedPath)
                .pipe(csv.parse({ headers: true }))
                .on('error', error => console.error(error))
                .on('data', row => {
                    for (const [idx, s] of _.values(row).slice(1).entries()) {
                        if (!phases[idx]) phases.push([]);
    
                        phases[idx][rowIdx] = +s;
                    }
                    rowIdx++;
                })
                .on('end', (rowCount: number) => {
                    console.log(`Parsed ${rowCount} rows`);
                    console.log('Total phases:', phases.length);
                    console.log('One phase size:', phases[0].length);
    
                    resolve(phases);
                });
        })

        const rawPhases = await parseCSV();
        const effect = new Effect();
        effect.name = 'New Effect';
        effect.block = block;
        await effect.save();

        const effectPhases: EffectPhase[] = [];
        for (const [idx, p] of rawPhases.entries()) {
            const ep = new EffectPhase();
            ep.effect = effect;
            ep.state = p;
            ep.sortOrder = idx;

            effectPhases.push(ep);
        }

        await EffectPhase.save(effectPhases);

        return 'ADDED';
    }

    public async getEffects() {
        return await Effect.find({ relations: ['block'] });
    }

    public async deleteEffect(id: number) {
        const effect = await this.getOne(id);
        await EffectPhase.delete({ id: In(effect.phases.map(p => p.id)) });
        await Effect.delete({ id: effect.id });

        return 'DONE';
    }

    public async editName(id: number, name: string) {
        const effect = await this.getOne(id);
        effect.name = name;
        await effect.save();

        return 'UPDATED';
    }

    public async addPhase(effectId: number) {
        const effect = await this.getOne(effectId);

        // Validate phrase
        const floors = await Floor.find({ block: { id: effect.block.id } });
        const apartmentCount = await Apartment.count({
            floor: { id: In(floors.map(f => f.id)) }
        });

        const bottomostPhase = await EffectPhase.findBottom(effectId);
        const effectPhase = new EffectPhase();
        effectPhase.state = _.fill(Array(apartmentCount), 0);
        effectPhase.sortOrder = bottomostPhase ? bottomostPhase.sortOrder + 1 : 0;
        effectPhase.effect = effect;

        await effectPhase.save();
        
        return 'ADDED';
    }


    public async getOnePhase(phaseId: number) {
        const phase = await EffectPhase.findOne({ id: phaseId });

        if (_.isEmpty(phase)) {
            throw new Error('Invalid phase id')
        }

        return phase;
    }

    public async editPhase(phaseId: number, state: number[]) {
        const phase = await this.getOnePhase(phaseId);

        if (_.size(state) != _.size(phase.state)) {
            throw new Error('Invalid phase size. In database: ' + _.size(phase.state));
        }

        phase.state = state;
        await phase.save();

        return 'UPDATED';
    }

    public async deletePhase(phaseId: number) {
        const phase = await this.getOnePhase(phaseId);

        await phase.remove();
        return 'DELETED';
    }

    public async changePhaseOrder(id: number, direction: OrderDirection) {
        const phase = await this.getOnePhase(id);

        const otherPhase = direction == OrderDirection.DOWN
            ? await EffectPhase.findBelow(id)
            : await EffectPhase.findAbove(id)

        if (!otherPhase) {
            throw new Error('Phase already at the top / bottom. Current sort order: ' + phase.sortOrder);
        }

        const currentSortOrder = phase.sortOrder;
        phase.sortOrder = otherPhase.sortOrder;
        otherPhase.sortOrder = currentSortOrder;

        await phase.save();
        await otherPhase.save();

        return 'DONE';
    }

    public async syncPhaseLength(blockId: number) {
        const effects = await Effect.find({ block: { id: blockId } });
        const apartmentCount = await Block.countApartments(blockId);

        for (const effect of effects) {
            const phases = await EffectPhase.find({ effect: { id: effect.id } });
            for (const phase of phases) {
                const diffSize = _.size(phase.state) - apartmentCount;
                phase.state = diffSize > 0
                    ? _.dropRight(phase.state, diffSize)
                    : _.concat(phase.state, _.fill(Array(-diffSize), 0));
            }

            await EffectPhase.save(phases);
        }

        return 'DONE';
    }
}