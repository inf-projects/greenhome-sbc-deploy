import 'reflect-metadata';

// Config environment variables
import dotenv from 'dotenv';
const envFound = dotenv.config();
if (!envFound) {
    throw new Error("⚠️  Couldn't find .env file  ⚠️");
}

import moment from 'moment-timezone';
import { ConnectionOptions, createConnection } from 'typeorm';
import morgan from 'morgan';

import { App } from './app';
import container from './container';
import { SERVICE_PORT, WORKING_DIR, UPLOAD_DIR, PUBLIC_DIR, DB_PATH, IS_TEST } from './config';
import { applyHttpResponseComposer } from './lib/response-composer';
import { initializeServices } from './services';
import { initializeControllers } from './controllers';
import logger, { morganStream } from './lib/logger';
import entities from './entities';
import { errorHandler } from './lib/errors';
import eventEmitter from './lib/event-emitter';
import { ServiceEvent } from './events';

// Set default timezone
moment.tz.setDefault('Asia/Ho_Chi_Minh');
logger.info('Timezone: ' + moment.tz.guess());
logger.info('Current time: ' + moment().unix());

// Binding service
export async function startServer() {
    logger.info('WORKING_DIR: ' + WORKING_DIR);
    logger.info('PUBLIC_DIR: ' + PUBLIC_DIR);
    logger.info('UPLOAD_DIR: ' + UPLOAD_DIR);
    logger.info('DB_PATH: ' + DB_PATH);

    eventEmitter.on(ServiceEvent.CRITIAL_ERROR, () => {
        logger.error('System has critical error. Exit now');
        process.exit(1);
    })

    try {
        const options: ConnectionOptions = {
            type: "sqlite",
            database: DB_PATH,
            synchronize: true,
            entities
        }

        await createConnection(options);
        
        await initializeServices(container);
        const app = new App(
            initializeControllers(container),
            +SERVICE_PORT,
            [
                applyHttpResponseComposer,
                morgan('combined', { stream: morganStream })
            ],
        );

        app.applyExternalMiddleware(errorHandler);
        return await app.listen();
    } catch (error) {
        logger.error(error.message);
        process.exit(1);
    }
};

if (!IS_TEST) {
    startServer();
}

