import { Entity, PrimaryGeneratedColumn, Column, BaseEntity, OneToMany, ManyToOne } from "typeorm";
import { Effect } from "./Effect";

@Entity()
export class EffectPhase extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('simple-json')
    state: number[];

    @Column('int')
    sortOrder: number;

    @ManyToOne(
        type => Effect,
        effect => effect.phases
    )
    effect: Effect

    static findBottom(effectId: number) {
        return this.createQueryBuilder('effectphase')
            .where('effectphase.effectId = :effectId', { effectId })
            .orderBy('effectphase.sortOrder', 'DESC')
            .getOne();
    }

    static async findAbove(id: number) {
        const phase = await EffectPhase.findOne({ id }, { relations: ['effect'] });
        return this.createQueryBuilder('effectphase')
            .where(`effectphase.sortOrder < :sortOrder`, { sortOrder: phase.sortOrder })
            .andWhere('effectphase.effectId = :effectId', { effectId: phase.effect.id })
            .orderBy('effectphase.sortOrder', 'DESC')
            .getOne();
    }

    static async findBelow(id: number) {
        const phase = await EffectPhase.findOne({ id }, { relations: ['effect'] });
        return this.createQueryBuilder('effectphase')
            .where(`effectphase.sortOrder > :sortOrder`, { sortOrder: phase.sortOrder })
            .andWhere('effectphase.effectId = :effectId', { effectId: phase.effect.id })
            .orderBy('effectphase.sortOrder', 'ASC')
            .getOne();
    }
}
