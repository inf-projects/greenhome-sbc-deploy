import { Entity, PrimaryGeneratedColumn, Column, BaseEntity, OneToMany, ManyToOne } from "typeorm";
import { Block } from "./Block";
import { EffectPhase } from "./EffectPhase";

@Entity()
export class Effect extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('text')
    name: string;

    @OneToMany(
        type => EffectPhase,
        effectPhase => effectPhase.effect 
    )
    phases: EffectPhase[]

    @ManyToOne(
        type => Block,
        block => block.effects
    )
    block: Block
}
