import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    BaseEntity,
    ManyToOne,
} from 'typeorm';
import { Floor } from './Floor';
import { ControlState } from '../types';

@Entity()
export class Apartment extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('text')
    name: string;

    @Column('simple-array')
    images: string[];

    @Column('int')
    state: ControlState;

    @Column({ type: 'int', nullable: true, default: ControlState.ON })
    defined?: ControlState;

    @Column({ type: 'boolean', nullable: true, default: false })
    activated?: boolean;

    @ManyToOne((type) => Floor, (floor) => floor.apartments)
    floor: Floor;

    @Column('int')
    sortOrder: number;

    static findByFloor(floorId: number) {
        return this.createQueryBuilder('apartment')
            .where('apartment.floorId = :floorId', { floorId })
            .orderBy('apartment.sortOrder', 'ASC')
            .getMany();
    }

    static findBottom(floorId: number) {
        return this.createQueryBuilder('apartment')
            .where('apartment.floorId = :floorId', { floorId })
            .orderBy('apartment.sortOrder', 'DESC')
            .getOne();
    }

    static async findAbove(id: number) {
        const currentApartment = await Apartment.findOne(
            { id },
            { relations: ['floor'] },
        );
        return this.createQueryBuilder('apartment')
            .where(`apartment.sortOrder < :sortOrder`, {
                sortOrder: currentApartment.sortOrder,
            })
            .andWhere('apartment.floorId = :floorId', {
                floorId: currentApartment.floor.id,
            })
            .orderBy('apartment.sortOrder', 'DESC')
            .getOne();
    }

    static async findBelow(id: number) {
        const currentApartment = await Apartment.findOne(
            { id },
            { relations: ['floor'] },
        );

        return this.createQueryBuilder('apartment')
            .where(`apartment.sortOrder > :sortOrder`, {
                sortOrder: currentApartment.sortOrder,
            })
            .andWhere('apartment.floorId = :floorId', {
                floorId: currentApartment.floor.id,
            })
            .orderBy('apartment.sortOrder', 'ASC')
            .getOne();
    }
}
