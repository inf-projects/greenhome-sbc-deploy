import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import useragent from 'express-useragent';
import { Server } from 'http';
import morgan from 'morgan';

import { Controller } from './controllers';

import { SERVICE_NAME, PUBLIC_DIR } from './config';
import logger from './lib/logger';

class App {
    public app: express.Application;
    public port: number;

    constructor(controllers: Controller[], port: number, middlewares: any[]) {
        this.app = express();
        this.port = port;

        this.initializeMiddlewares(middlewares);
        this.initializeControllers(controllers);
    }

    private initializeMiddlewares(middlewares: any[]) {
        this.app.disable('x-powered-by');
        this.app.use(bodyParser.urlencoded({ limit: '500mb', extended: true }));
        this.app.use(bodyParser.json({ limit: '500mb' }));
        this.app.use(cors());
        this.app.use(useragent.express());

        this.app.use('/public', express.static(PUBLIC_DIR));
        this.app.get('/ping', (req, res) => res.send('OK'));

        // this.app.get('/test', async (req, res) => {
        //     try {
        //         res.json(await Block.countApartments(1));
        //     } catch (err) {
        //         res.status(400).send(err.message);
        //     }
        // });

        middlewares.forEach(m => this.app.use(m));
    }

    public applyExternalMiddleware(middleware: any) {
        this.app.use(middleware);
    }

    private initializeControllers(controllers: Controller[]) {
        controllers.forEach(controller => {
            this.app.use(controller.path, controller.router);
        });
    }

    public listen(): Promise<Server> {
        return new Promise(resolve => {
            const server = this.app.listen(this.port, () => {
                logger.info(`[${SERVICE_NAME}] listening on the port ${this.port}`);
                resolve(server);
            });
        })
    }
}

export { App };