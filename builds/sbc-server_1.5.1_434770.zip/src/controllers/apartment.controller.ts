import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import { check, validationResult, body, sanitizeBody, matchedData, query } from 'express-validator';

import { Controller } from '.';
import { Service, ControlState, OrderDirection } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { ApartmentService, ControlService } from '../services';
import { wrap } from '../lib/helper';

@injectable()
export class ApartmentController extends Controller {
    public readonly router = Router();
    public readonly path = '/apartments';

    constructor(
        @inject(Service.Apartment) private apartmentService: ApartmentService,
        @inject(Service.Control) private controlService: ControlService
    ) {
        super();

        this.router.get('/', [
                query('floor').not().isEmpty().toInt()
            ],
            wrap(this.getAllApartments.bind(this))
        );
        this.router.get('/:id',
            wrap(this.getApartmentById.bind(this))
        );
        this.router.post('/', [
                body('floor').not().isEmpty().toInt()
            ],
            wrap(this.addApartment.bind(this))
        );

        this.router.patch('/:id', [
                body('name').not().isEmpty().trim(),
            ],
            wrap(this.editApartment.bind(this))
        );
        this.router.delete('/:id',
            wrap(this.deleteApartment.bind(this))
        )

        // Image releated apis
        this.router.post('/:id/image', wrap(this.addApartmentImage.bind(this)));
        this.router.delete('/:id/image',
            [
                body('imagePath').not().isEmpty().trim()
            ],
            wrap(this.deleteApartmentImage.bind(this))
        );

        // Control APIs
        this.router.post('/:id/control',
            [
                body('state').exists().toInt().custom(value => value === ControlState.ON || value === ControlState.OFF)
            ],
            wrap(this.control.bind(this))
        );
        this.router.post('/:id/order', [
            body('direction').exists().toInt().custom(value => value === OrderDirection.DOWN || value === OrderDirection.UP)
        ],
            wrap(this.changeOrder.bind(this))
        );
        this.router.post('/:id/floor', [
            body('floor').exists().toInt()
        ],
            wrap(this.changeFloor.bind(this))
        );

        logger.info('[Apartment controller] initialized');
    }

    async getAllApartments(req: Request, res: Response) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { floor } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.apartmentService.getByFloorId(floor));
    }

    async getApartmentById(req: Request, res: Response) {
        const { id } = req.params;
        return res.composer.success(await this.apartmentService.getOne(+id));
    }

    async addApartment(req: Request, res: Response) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { floor } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.apartmentService.addApartment(floor));
    }

    async editApartment(req: Request, res: Response, next: NextFunction) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { name } = matchedData(req, { includeOptionals: false });
        const { id } = req.params;

        return res.composer.success(await this.apartmentService.editName(+id, name));
    }

    async deleteApartment(req: Request, res: Response, next: NextFunction) {
        const { id } = req.params;
        return res.composer.success(await this.apartmentService.delete(+id, true));
    }

    async addApartmentImage(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.apartmentService.addApartmentImage(+id, req));
    }

    async deleteApartmentImage(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { imagePath } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.apartmentService.deleteApartmentImage(+id, imagePath));
    }

    async control(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { state } = matchedData(req, { includeOptionals: false });
        const updatedApartment = await this.controlService.updateApartmentState(+id, state);

        res.composer.success(updatedApartment);
    }

    async changeOrder(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { direction } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.apartmentService.changeOrder(+id, direction));
    }

    async changeFloor(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { floor } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.apartmentService.changeFloor(+id, floor));
    }
}
