import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import { check, validationResult, body, sanitizeBody, matchedData, query } from 'express-validator';

import { Controller } from '.';
import { Service, ControlState, OrderDirection } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { FloorService, ControlService } from '../services';
import { wrap } from '../lib/helper';

@injectable()
export class FloorController extends Controller {
    public readonly router = Router();
    public readonly path = '/floors';

    constructor(
        @inject(Service.Floor) private floorService: FloorService,
        @inject(Service.Control) private controlService: ControlService
    ) {
        super();

        this.router.get('/', [
                query('block').not().isEmpty().toInt()
            ],
            wrap(this.getAllFloors.bind(this))
        );
        this.router.get('/:id',
            wrap(this.getFloorById.bind(this))
        );
        this.router.post('/', [
            body('block').not().isEmpty().toInt()
        ],
            wrap(this.addFloor.bind(this))
        );

        this.router.patch('/:id',
            [
                body('name').not().isEmpty().trim(),
            ],
            wrap(this.editFloor.bind(this))
        );
        this.router.delete('/:id',
            wrap(this.deleteFloor.bind(this))
        )

        // Image related apis
        this.router.post('/:id/image', wrap(this.addFloorImage.bind(this)));
        this.router.delete('/:id/image',
            [
                body('imagePath').not().isEmpty().trim()
            ],
            wrap(this.deleteFloorImage.bind(this))
        );
        this.router.post('/:id/background', wrap(this.addFloorBackground.bind(this)));

        // Control APIs
        this.router.post('/:id/control',
            [
                body('state').exists().toInt().custom(value => value === ControlState.ON || value === ControlState.OFF)
            ],
            wrap(this.control.bind(this))
        );
        this.router.post('/:id/order', [
            body('direction').exists().toInt().custom(value => value === OrderDirection.DOWN || value === OrderDirection.UP)
        ],
            wrap(this.changeOrder.bind(this))
        )

        logger.info('[Floor controller] initialized');
    }

    async addFloor(req: Request, res: Response) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { block } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.floorService.addFloor(block));
    }

    async getAllFloors(req: Request, res: Response) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { block } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.floorService.getByBlockId(block));
    }

    async getFloorById(req: Request, res: Response) {
        const { id } = req.params;
        return res.composer.success(await this.floorService.getOne(+id, true));
    }

    async editFloor(req: Request, res: Response, next: NextFunction) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { name } = matchedData(req, { includeOptionals: false });
        const { id } = req.params;

        return res.composer.success(await this.floorService.editName(+id, name));
    }

    async deleteFloor(req: Request, res: Response, next: NextFunction) {
        const { id } = req.params;
        return res.composer.success(await this.floorService.delete(+id, true));
    }

    async addFloorImage(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.floorService.addFloorImage(+id, req));
    }

    async addFloorBackground(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.floorService.addFloorBackground(+id, req));
    }

    async deleteFloorImage(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { imagePath } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.floorService.deleteFloorImage(+id, imagePath));
    }

    async control(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { state } = matchedData(req, { includeOptionals: false });
        const updatedApartment = await this.controlService.updateFloorState(+id, state);

        res.composer.success(updatedApartment);
    }

    async changeOrder(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { direction } = matchedData(req, { includeOptionals: false });
        res.composer.success(await this.floorService.changeOrder(+id, direction));
    }
}
