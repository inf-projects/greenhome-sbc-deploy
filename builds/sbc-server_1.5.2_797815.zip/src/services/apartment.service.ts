import { inject, injectable } from 'inversify';
import _ from 'lodash';
import fs from 'fs-extra';
import path from 'path';

import logger from '../lib/logger';
import { WORKING_DIR } from '../config';
import { Block, Apartment, Floor } from '../entities';
import { ControlState, Service, OrderDirection } from '../types';
import { UploadService } from './upload.service';
import { Request } from '../lib/response-composer';
import { getManager } from 'typeorm';
import { EffectService } from './effect.service';

// Define an interface for the update data for better type-safety and clarity
interface IApartmentUpdateData {
    name?: string;
    defined?: ControlState;
}

@injectable()
export class ApartmentService {
    constructor(
        @inject(Service.Upload) private uploadService: UploadService,
        @inject(Service.Effect) private effectService: EffectService,
    ) {
        logger.info('[Apartment service] Construct');
    }

    public getByFloorId(floorId: number) {
        return Apartment.findByFloor(floorId);
    }

    async getOne(id: number, joinFloor = false) {
        const apartment = await Apartment.findOne(
            { id },
            { relations: joinFloor ? ['floor'] : [] },
        );

        if (_.isEmpty(apartment)) {
            throw new Error('Invalid apartment id');
        }

        return apartment;
    }

    public async addApartment(floorId: number) {
        const floor = await Floor.findOne(
            { id: floorId },
            { relations: ['block'] },
        );

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        const bottomostApartment = await Apartment.findBottom(floorId);

        const apartment = new Apartment();
        apartment.name = `New Apartment`;
        apartment.images = [];
        apartment.state = ControlState.OFF;
        apartment.floor = floor;
        apartment.sortOrder = bottomostApartment
            ? bottomostApartment.sortOrder + 1
            : 0;
        await apartment.save();

        await this.effectService.syncPhaseLength(floor.block.id);

        return apartment;
    }

    public async editName(id: number, apName: string) {
        const apartment = await Apartment.findOne({ id });

        if (_.isEmpty(apartment)) {
            throw new Error('Invalid apartment id');
        }

        // [Update 1.2] Use the convention _ to indicate the defined state of the apartment
        const [name, defined] = apName.split('_');

        apartment.name = name;
        if (defined) {
            apartment.defined = Number.parseInt(defined) as ControlState;
        }

        await apartment.save();

        return apartment;
    }

    /**
     * Edits an apartment with the given data.
     * This method can handle partial updates (e.g., only name, only defined, or both).
     * @param id The ID of the apartment to edit.
     * @param updateData An object containing the fields to update.
     */
    public async edit(id: number, updateData: IApartmentUpdateData) {
        const apartment = await this.getOne(id);

        // Object.assign is a clean way to apply the updates.
        // It copies the properties from updateData to the apartment entity.
        Object.assign(apartment, updateData);

        await apartment.save();

        return apartment;
    }

    public async addApartmentImage(id: number, req: Request) {
        const apartment = await Apartment.findOne({ id });

        if (_.isEmpty(apartment)) {
            throw new Error('Invalid apartment id');
        }

        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'apartment_',
        );
        apartment.images.push(uploadedPath);
        await apartment.save();

        return apartment;
    }

    public async deleteApartmentImage(id: number, imagePath: string) {
        const apartment = await Apartment.findOne({ id });

        if (_.isEmpty(apartment)) {
            throw new Error('Invalid apartment id');
        }

        if (_.indexOf(apartment.images, imagePath) == -1) {
            throw new Error('Invalid image path / Empty images');
        }

        _.pull(apartment.images, imagePath);
        await apartment.save();

        await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));

        return apartment;
    }

    public async changeOrder(id: number, direction: OrderDirection) {
        const currentApartment = await Apartment.findOne(
            { id },
            { relations: ['floor'] },
        );

        if (_.isEmpty(currentApartment)) {
            throw new Error('Invalid apartment id');
        }

        const otherApartment =
            direction == OrderDirection.DOWN
                ? await Apartment.findBelow(id)
                : await Apartment.findAbove(id);

        if (!otherApartment) {
            throw new Error(
                'Apartment already at the top / bottom. Current sort order: ' +
                    currentApartment.sortOrder,
            );
        }

        const currentSortOrder = currentApartment.sortOrder;
        currentApartment.sortOrder = otherApartment.sortOrder;
        otherApartment.sortOrder = currentSortOrder;

        await currentApartment.save();
        await otherApartment.save();

        return 'DONE';
    }

    public async changeFloor(id: number, newFloorId: number) {
        const currentApartment = await this.getOne(id, true);

        if (newFloorId == currentApartment.floor.id) {
            throw new Error(
                'New floor same as current floor. Current floor: ' +
                    currentApartment.floor.id,
            );
        }

        const newFloor = await Floor.findOne({ id: newFloorId });
        if (_.isEmpty(newFloor)) {
            throw new Error('Invalid floor id');
        }

        const bottomostApartment = await Apartment.findBottom(newFloorId);
        currentApartment.floor = newFloor;
        currentApartment.sortOrder = bottomostApartment
            ? bottomostApartment.sortOrder + 1
            : 0;
        await currentApartment.save();

        return 'DONE';
    }

    public async delete(id: number, shouldUpdateEffect = false) {
        const apartment = await this.getOne(id, true);

        // Delete all images in apartments
        for (const imagePath of apartment.images) {
            await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));
        }

        await Apartment.delete({ id: apartment.id });

        // Update effect accordingly
        if (shouldUpdateEffect) {
            const floor = await Floor.findOne(
                { id: apartment.floor.id },
                { relations: ['block'] },
            );
            await this.effectService.syncPhaseLength(floor.block.id);
        }

        return 'DELETED';
    }
}
