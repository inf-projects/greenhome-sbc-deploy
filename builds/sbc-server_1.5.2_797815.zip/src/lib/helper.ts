import _ from 'lodash';
import crypto from 'crypto';
import { Request } from 'express';
import { matchedData, validationResult } from 'express-validator';

const CHARACTERS = '01234defghijkl56789NOPQRSTUVWXYZabcmnoABCDEFGHIJKLMpqrstuvwxyz';

export type EncodeCompressionLevel = 0 | 1 | 2;

export function castToBoolean(value: string) {
    return /true/i.test(value);
}

export function randomPassword(length: number) {
    return [...new Array(length)].map(() => CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)]).join('');
}

export function generateRandomStringNumber(length: number) {
    let numberString = '';
    for (let i = 0; i < length; i++) {
        numberString += Math.floor(Math.random() * 10);
    }
    return numberString;
}

export function encodeObjectId(objectId: string, compressLevel: EncodeCompressionLevel = 0) {
    let blocks = [];
    if (compressLevel == 1) {
        blocks = [parseInt(objectId.slice(8, 16), 16), parseInt(objectId.slice(16), 16)];
    } else if (compressLevel == 2) {
        blocks = [parseInt(objectId.slice(18), 16)];
        if (Math.random() > 0.5) {
            blocks = [...blocks, Math.floor(Math.random() * 128)];
        } else {
            blocks = [Math.floor(Math.random() * 128), ...blocks];
        }
    } else {
        blocks = [parseInt(objectId.slice(0, 12), 16), parseInt(objectId.slice(12), 16)];
    }

    return blocks
        .map(n => {
            let bundleSlug = '';
            while (n > 0) {
                bundleSlug += CHARACTERS[n % 62];
                n = Math.floor(n / 62);
            }
            return bundleSlug;
        })
        .join('');
}

export function keysToEnum<T extends string>(o: Array<T>): {[K in T]: K} {
    return o.reduce((res, key) => {
      res[key] = key;
      return res;
    }, Object.create(null));
}

export const wrap = (fn: any) => (...args: any[]) => fn(...args).catch(args[2]);

export function extractRequestData(req: Request) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        throw new Error(JSON.stringify(errors.array()));
    }

    return matchedData(req, { includeOptionals: false });
}

export function delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
