import { Request, Response } from "./response-composer";
import logger from "./logger";
import { NextFunction } from "express";

export class ErrorUnauthorized extends Error {}

export class ErrorInvalidData extends Error {}

export class ErrorNotFound extends Error {}

// User error
export class ErrorUserInvalid extends Error {
    public static readonly code = 'user/invalid';
    message = 'Invalid User';
}

// Bundle error
export class ErrorBundleInvalid extends Error {
    public static readonly code = 'bundle/invalid';
    message = 'Invalid Bundle';
}

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
    logger.error(err.stack);
    res.composer.badRequest("", err.toString());
};
