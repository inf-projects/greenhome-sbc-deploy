import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import { check, validationResult, body, sanitizeBody, matchedData, query } from 'express-validator';

import { Controller } from '.';
import { Service, ControlState, OrderDirection } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { FloorService, ControlService, SystemService, EffectService } from '../services';
import { wrap, extractRequestData } from '../lib/helper';

@injectable()
export class EffectController extends Controller {
    public readonly router = Router();
    public readonly path = '/effects';

    constructor(@inject(Service.Effect) private effectService: EffectService) {
        super();

        this.router.get('/', wrap(this.getEffectsByBlock.bind(this)));
        
        this.router.get('/:id', wrap(this.getSpecificEffect.bind(this)));
        this.router.delete('/:id', wrap(this.deleteEffect.bind(this)));
        this.router.patch('/:id', [
            body('name').not().isEmpty().trim(),
        ],
            wrap(this.editEffect.bind(this))
        );

        this.router.post(
            '/',
            this.addEffect.bind(this),
        );

        logger.info('[Effect controller] initialized');
    }

    async getEffectsByBlock(req: Request, res: Response) {
        res.composer.success(await this.effectService.getEffects());
    }

    async getSpecificEffect(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.effectService.getOne(+id));
    }

    async addEffect(req: Request, res: Response) {
        res.composer.success(await this.effectService.addEffect(req));
    }

    async deleteEffect(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.effectService.deleteEffect(+id));
    }

    async editEffect(req: Request, res: Response, next: NextFunction) {
        const { name } = extractRequestData(req);
        const { id } = req.params;

        return res.composer.success(await this.effectService.editName(+id, name));
    }
}
