import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import { check, validationResult, body, sanitizeBody, matchedData, query } from 'express-validator';

import { Controller } from '.';
import { Service, ControlState, OrderDirection } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { FloorService, ControlService, SystemService, EffectService } from '../services';
import { wrap, extractRequestData } from '../lib/helper';

@injectable()
export class EffectPhaseController extends Controller {
    public readonly router = Router();
    public readonly path = '/effect-phases';

    constructor(@inject(Service.Effect) private effectService: EffectService) {
        super();

        this.router.post(
            '/',
            [
                body('effect').notEmpty().toInt(),
            ],
            wrap(this.addEffectPhase.bind(this))
        )

        this.router.patch(
            '/:id',
            [
                body('state').isArray(),
            ],
            wrap(this.editEffectPhase.bind(this))
        );

        this.router.delete('/:id', wrap(this.deleteEffectPhase.bind(this)));

        this.router.post('/:id/order', [
            body('direction').exists().toInt().custom(value => value === OrderDirection.DOWN || value === OrderDirection.UP)
        ],
            wrap(this.changeOrder.bind(this))
        );

        logger.info('[Effect phase controller] initialized');
    }

    async addEffectPhase(req: Request, res: Response) {
        const { effect } = extractRequestData(req);
        res.composer.success(await this.effectService.addPhase(effect));
    }

    async editEffectPhase(req: Request, res: Response) {
        const { id } = req.params;
        const { state } = extractRequestData(req);
        res.composer.success(await this.effectService.editPhase(+id, state));
    }

    async deleteEffectPhase(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.effectService.deletePhase(+id));
    }

    async changeOrder(req: Request, res: Response) {
        const { id } = req.params;
        const { direction } = extractRequestData(req);

        res.composer.success(await this.effectService.changePhaseOrder(+id, direction));
    }
}
