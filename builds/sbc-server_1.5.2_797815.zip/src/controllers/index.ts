import { Application } from 'express';
import { Container } from 'inversify';

import { Router } from 'express';
import { inject, injectable } from 'inversify';

@injectable()
export abstract class Controller {
    public abstract readonly router: Router;
    public abstract readonly path: string;
}

import { BlockController } from './block.controller';
import { FloorController } from './floor.controller';
import { ApartmentController } from './apartment.controller';
import { SystemController } from './system.controller';
import { EffectController } from './effect.controller';
import { EffectPhaseController } from './effect-phase.controller';

export function initializeControllers(container: Container) {
    return [
        container.resolve<BlockController>(BlockController),
        container.resolve<FloorController>(FloorController),
        container.resolve<ApartmentController>(ApartmentController),
        container.resolve<SystemController>(SystemController),
        container.resolve<EffectController>(EffectController),
        container.resolve<EffectPhaseController>(EffectPhaseController),
    ];
}