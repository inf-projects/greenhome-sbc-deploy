export enum PrivacyType {
    PUBLIC = 'public',
    PROTECTED = 'protected',
    PRIVATE = 'private',
}

export enum HttpMethod {
    GET = 'GET',
    POST = 'POST',
    PUT = 'PUT',
    PATCH = 'PATCH',
    DELETE = 'DELETE',
}

export enum Gender {
    MALE = 'male',
    FEMALE = 'female',
    OTHER = 'other',
}

export enum Language {
    VIETNAMESE = 'vi',
    ENGLISH = 'en',
}

export type SortOrder = 'asc' | 'desc';

export enum ControlState {
    OFF = 0,
    ON = 1,
    AUTO = 2,
}

export const Service = {
    Block: Symbol.for('block'),
    Floor: Symbol.for('floor'),
    Apartment: Symbol.for('apartment'),
    Control: Symbol.for('control'),
    Effect: Symbol.for('effect'),
    Upload: Symbol.for('upload'),
    System: Symbol.for('system'),
};

export enum OrderDirection {
    UP = -1,
    DOWN = 1,
}
