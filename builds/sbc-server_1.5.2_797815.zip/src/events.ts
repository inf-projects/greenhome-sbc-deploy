export enum ServiceEvent {
    DATABASE_INITIALIZED = 'database-initialized',
    STORAGE_INITIALIZED = 'storage-initialized',
    CRITIAL_ERROR = 'critical-error',
    SERIAL_PORT_OPENED = 'serial-port-opened'
}