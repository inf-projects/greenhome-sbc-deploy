import { Entity, PrimaryGeneratedColumn, Column, BaseEntity, OneToMany, OneToOne, getManager } from "typeorm";
import { Effect } from "./Effect";
import { Floor } from "./Floor";
import { Apartment } from ".";

@Entity()
export class Block extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('text')
    name: string;

    @Column('simple-array')
    images: string[];

    @Column({ type: 'text', default: '' })
    background?: string;

    @OneToMany(
        type => Floor,
        floor => floor.block
    )
    floors: Floor[];

    @Column('text')
    state: 'manual' | 'auto';

    @Column({ type: 'int', default: 0 })
    positionX: number;

    @Column({ type: 'int', default: 0 })
    positionY: number;

    @OneToMany(
        type => Effect,
        effect => effect.block
    )
    effects: Effect[];

    @Column({ type: 'int', default: 0 })
    activeEffectId: number;

    @Column({ type: 'int', default: 1000 })
    effectSpeed: number;

    @Column('int')
    sortOrder: number;

    @Column({ type: 'int', default: 0 })
    output: number;

    static findBottom() {
        return this.createQueryBuilder('block')
            .orderBy('block.sortOrder', 'DESC')
            .getOne();
    }

    static async findBelow(id: number) {
        const currentBlock = await Block.findOne({ id });

        return this.createQueryBuilder('block')
            .where(`block.sortOrder > :sortOrder`, { sortOrder: currentBlock.sortOrder })
            .orderBy('block.sortOrder', 'ASC')
            .getOne();
    }

    static async findAbove(id: number) {
        const currentBlock = await Block.findOne({ id });

        return this.createQueryBuilder('block')
            .where(`block.sortOrder < :sortOrder`, { sortOrder: currentBlock.sortOrder })
            .orderBy('block.sortOrder', 'DESC')
            .getOne();
    }

    static async countApartments(blockId: number) {
        const manager = getManager();
        const floorIds = (await manager.createQueryBuilder(Floor, 'floor')
            .select('floor.id')
            .where(`floor.blockId = :blockId`, { blockId })
            .getMany())
            .map(f => f.id);
        
        return manager.createQueryBuilder(Apartment, 'apartment')
            .where('apartment.floorId IN (:...floorIds)', { floorIds })
            .getCount();
    }

    static async findApartments(blockId: number) {
        const manager = getManager();
        const floorIds = (await manager.createQueryBuilder(Floor, 'floor')
            .select('floor.id')
            .where(`floor.blockId = :blockId`, { blockId })
            .getMany())
            .map(f => f.id);

        return manager.createQueryBuilder(Apartment, 'apartment')
            .where('apartment.floorId IN (:...floorIds)', { floorIds })
            .orderBy('floorId', 'ASC')
            .addOrderBy('sortOrder', 'ASC')
            .getMany();
    }
}
