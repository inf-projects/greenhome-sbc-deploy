import { Entity, PrimaryGeneratedColumn, Column, BaseEntity, OneToMany, ManyToOne } from "typeorm";
import { Apartment } from "./Apartment";
import { Block } from "./Block";

@Entity()
export class Floor extends BaseEntity {
    @PrimaryGeneratedColumn()
    id: number;

    @Column('text')
    name: string;

    @Column('simple-array')
    images: string[];

    @Column({ type: 'text', default: '' })
    background?: string;

    @OneToMany(
        type => Apartment,
        apartment => apartment.floor
    )
    apartments: Apartment[];

    @ManyToOne(
        type => Block,
        block => block.floors
    )
    block: Block;

    @Column('int')
    sortOrder: number;

    static findByBlock(blockId: number) {
        return this.createQueryBuilder('floor')
            .where('floor.blockId = :blockId', { blockId })
            .orderBy('floor.sortOrder', 'ASC')
            .getMany();
    }

    static findBottom(blockId: number) {
        return this.createQueryBuilder('floor')
            .where('floor.blockId = :blockId', { blockId })
            .orderBy('floor.sortOrder', 'DESC')
            .getOne();
    }

    static async findBelow(id: number) {
        const currentFloor = await Floor.findOne({ id }, { relations: ['block'] });
        
        return this.createQueryBuilder('floor')
            .where(`floor.sortOrder > :sortOrder`, { sortOrder: currentFloor.sortOrder })
            .andWhere('floor.blockId = :blockId', { blockId: currentFloor.block.id })
            .orderBy('floor.sortOrder', 'ASC')
            .getOne();
    }

    static async findAbove(id: number) {
        const currentFloor = await Floor.findOne({ id }, { relations: ['block'] });

        return this.createQueryBuilder('floor')
            .where(`floor.sortOrder < :sortOrder`, { sortOrder: currentFloor.sortOrder })
            .andWhere('floor.blockId = :blockId', { blockId: currentFloor.block.id })
            .orderBy('floor.sortOrder', 'DESC')
            .getOne();
    }
}
