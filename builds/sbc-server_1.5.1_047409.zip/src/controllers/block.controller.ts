import { Router, NextFunction } from 'express';
import { inject, injectable } from 'inversify';
import _ from 'lodash';
import {
    validationResult,
    body,
    matchedData,
} from 'express-validator';

import { Controller } from '.';
import { Service, ControlState, OrderDirection } from '../types';
import { Request, Response } from '../lib/response-composer';
import logger from '../lib/logger';
import { BlockService, ControlService } from '../services';
import { wrap } from '../lib/helper';

@injectable()
export class BlockController extends Controller {
    public readonly router = Router();
    public readonly path = '/blocks';

    constructor(
        @inject(Service.Block) private blockService: BlockService,
        @inject(Service.Control) private controlService: ControlService,
    ) {
        super();

        // Confing child routes
        this.router.post('/', wrap(this.createBlock.bind(this)));
        this.router.get('/', wrap(this.getAllBlocks.bind(this)));
        this.router.get('/:id', wrap(this.getBlockById.bind(this)));
        this.router.patch(
            '/:id',
            [
                body('name').optional().not().isEmpty().trim(),
                body('positionX').optional().not().isEmpty().trim(),
                body('positionY').optional().not().isEmpty().trim(),
                body('effectSpeed').optional().not().isEmpty().toInt(),
                body('output').optional().not().isEmpty().toInt(),
            ],
            wrap(this.editBlock.bind(this)),
        );
        this.router.delete('/:id', wrap(this.deleteBlock.bind(this)));

        // Images apis
        this.router.post('/:id/image', wrap(this.addBlockImage.bind(this)));
        this.router.delete(
            '/:id/image',
            [body('imagePath').not().isEmpty().trim()],
            wrap(this.deleteBlockImage.bind(this)),
        );
        this.router.post(
            '/:id/background',
            wrap(this.addBlockBackground.bind(this)),
        );

        // Control APIs
        this.router.post(
            '/:id/control',
            [
                body('state')
                    .exists()
                    .toInt()
                    .custom(
                        (value) =>
                            value === ControlState.ON ||
                            value === ControlState.OFF,
                    ),
            ],
            wrap(this.control.bind(this)),
        );
        this.router.post(
            '/:id/auto',
            [body('effect').exists().toInt()],
            wrap(this.auto.bind(this)),
        );
        this.router.post(
            '/:id/order',
            [
                body('direction')
                    .exists()
                    .toInt()
                    .custom(
                        (value) =>
                            value === OrderDirection.DOWN ||
                            value === OrderDirection.UP,
                    ),
            ],
            wrap(this.changeOrder.bind(this)),
        );

        logger.info('[Block controller] initialized');
    }

    async createBlock(req: Request, res: Response) {
        const usingFile = !!req.query.usingFile;

        if (usingFile) {
            res.composer.success(
                await this.blockService.createBlockWithFile(req),
            );
        } else {
            res.composer.success(await this.blockService.createBlock());
        }
    }

    async getAllBlocks(req: Request, res: Response) {
        res.composer.success(await this.blockService.getBlocks());
    }

    async getBlockById(req: Request, res: Response) {
        const { id } = req.params;
        return res.composer.success(await this.blockService.getOne(+id, true));
    }

    async editBlock(req: Request, res: Response, next: NextFunction) {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const data = matchedData(req, { includeOptionals: false });

        if (_.isEmpty(data)) {
            throw new Error('Empty data');
        }

        const { id } = req.params;
        return res.composer.success(await this.blockService.update(+id, data));
    }

    async deleteBlock(req: Request, res: Response, next: NextFunction) {
        const { id } = req.params;
        return res.composer.success(await this.blockService.delete(+id));
    }

    async addBlockImage(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(await this.blockService.addBlockImage(+id, req));
    }

    async addBlockBackground(req: Request, res: Response) {
        const { id } = req.params;
        res.composer.success(
            await this.blockService.addBlockBackground(+id, req),
        );
    }

    async deleteBlockImage(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { imagePath } = matchedData(req, { includeOptionals: false });
        res.composer.success(
            await this.blockService.deleteBlockImage(+id, imagePath),
        );
    }

    async control(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { state } = matchedData(req, { includeOptionals: false });
        const updatedApartment = await this.controlService.updateBlockState(
            +id,
            state,
        );

        res.composer.success(updatedApartment);
    }

    async auto(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { effect } = matchedData(req, { includeOptionals: false });
        res.composer.success(
            await this.controlService.startBlockEffect(+id, effect),
        );
    }

    async changeOrder(req: Request, res: Response) {
        const { id } = req.params;
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            throw new Error(JSON.stringify(errors.array()));
        }

        const { direction } = matchedData(req, { includeOptionals: false });
        res.composer.success(
            await this.blockService.changeOrder(+id, direction),
        );
    }
}
