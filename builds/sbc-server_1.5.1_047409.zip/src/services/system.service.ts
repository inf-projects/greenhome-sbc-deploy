import { inject, injectable, LazyServiceIdentifer } from 'inversify';
import _ from 'lodash';
import fs from 'fs-extra';
import path from 'path';
import SoundPlayer from 'sound-player';
import { ChildProcess, execSync, spawn } from 'child_process';

import logger from '../lib/logger';
import { WORKING_DIR, CONFIG_FILE } from '../config';
import { Service } from '../types';
import { UploadService } from './upload.service';
import { Request } from '../lib/response-composer';

interface SystemConfig {
    password: string;
    background: string;
    logo: string;
    audio: string;
    video: string[];
    idleVideo: string;
    isAudioPlaying: boolean;
    displayMode: string;
}

const DEFAULT_CONFIG: SystemConfig = {
    password: '123',
    background: '',
    logo: '',
    audio: '',
    video: [],
    isAudioPlaying: false,
    displayMode: 'mode1',
    idleVideo: '',
};

@injectable()
export class SystemService {
    config: SystemConfig;

    // player: any;
    // playerOptions = {
    //     filename: "",
    //     gain: 100,
    //     debug: true,
    //     player: "mpg321",
    //     device: "sysdefault:CARD=Headphones"
    // };

    audioProcess: ChildProcess = null;
    audioFilePath: string;

    imageProcess: ChildProcess = null;
    videoProcess: ChildProcess = null;

    constructor(
        @inject(Service.Upload) private uploadService: UploadService,
    ) {
        logger.info('[System service] Construct');

        this.loadConfig().then(() => this.restoreState());

        // this.player = new SoundPlayer(this.playerOptions);

        // this.player.on("complete", () => {
        //     logger.error("Done with playback!");
        //     this.player.play();
        // });

        // this.player.on("error", (err: any) => {
        //     logger.error("Error occurred:", err);
        // });
    }

    playAudio() {
        if (this.config.isAudioPlaying) {
            console.log('# [AUDIO] Is playing');
        }

        console.log('-> [AUDIO] Play audio:', this.audioFilePath);

        this.audioProcess = spawn('mpg321', [
            '-g',
            '100',
            //    '--vol', '-2000',
            this.audioFilePath,
        ]);

        this.audioProcess.on('close', this.onAudioClose.bind(this));
        this.audioProcess.stdout.on('data', this.onAudioPlaying.bind(this));
    }

    stopAudio() {
        console.log('-> [AUDIO] Stop audio');
        try {
            execSync('pkill mpg321');
            this.audioProcess = null;
        } catch (err) {
            console.log('-> [AUDIO STOP ERROR] ' + err.message);
        }
    }

    onAudioClose(code: any) {
        console.log('-> Audio play finish with code:', code);

        if (this.config.isAudioPlaying) this.playAudio();
    }

    onAudioPlaying(data: any) {
        console.log(data);
    }

    async restoreState() {
        if (this.config.isAudioPlaying) {
            // this.playerOptions.filename = path.join(WORKING_DIR, 'public', this.config.audio);
            // this.player.play(this.playerOptions);
            this.audioFilePath = path.join(
                WORKING_DIR,
                'public',
                this.config.audio,
            );
            this.playAudio();
        }

        // Show background as default
        if (this.config.background) {
            this.showImage(this.config.background);
        }
    }

    async loadConfig() {
        if (fs.existsSync(CONFIG_FILE)) {
            this.config = fs.readJSONSync(CONFIG_FILE) as SystemConfig;
        } else {
            this.config = DEFAULT_CONFIG;
        }

        // Fill missing config values if any
        this.config = {
            ...DEFAULT_CONFIG,
            ...this.config,
        };

        // Save the config if it was created
        await this.saveConfig();
    }

    async saveConfig() {
        fs.writeJSONSync(CONFIG_FILE, this.config);
    }

    getConfig() {
        return this.config;
    }

    public async addBackground(req: Request) {
        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'background_',
        );

        // Delete old images
        if (this.config.background) {
            await fs.unlink(
                path.join(WORKING_DIR, 'public', this.config.background),
            );
        }

        this.config.background = uploadedPath;
        this.saveConfig();

        return this.config;
    }

    public async addLogo(req: Request) {
        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'logo_',
        );

        // Delete old images
        if (this.config.logo) {
            await fs.unlink(path.join(WORKING_DIR, 'public', this.config.logo));
        }

        this.config.logo = uploadedPath;

        await this.saveConfig();

        return this.config;
    }

    public async changePassword(password: string) {
        this.config.password = password;
        await this.saveConfig();

        return this.config;
    }

    public async addAudio(req: Request) {
        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'audio_',
        );

        // Delete old audio
        if (this.config.audio) {
            await fs.unlink(
                path.join(WORKING_DIR, 'public', this.config.audio),
            );
        }

        this.config.audio = uploadedPath;
        await this.saveConfig();

        return this.config;
    }

    public async addVideo(req: Request) {
        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            `video_${Date.now().toString().slice(-6)}_`,
        );

        this.config.video.push(uploadedPath);
        await this.saveConfig();

        return this.config;
    }

    public async removeVideo(video: string) {
        const videoIndex = this.config.video.indexOf(video);
        if (videoIndex > -1) {
            this.config.video.splice(videoIndex, 1);
        }

        // Delete the video file
        await fs.unlink(path.join(WORKING_DIR, 'public', video));

        await this.saveConfig();

        return this.config;
    }

    public async updateIdleVideo(req: Request) {
        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'idle_video_',
        );

        // Delete old idle video
        if (this.config.idleVideo) {
            await fs.unlink(
                path.join(WORKING_DIR, 'public', this.config.idleVideo),
            );
        }

        this.config.idleVideo = uploadedPath;
        await this.saveConfig();

        return this.config;
    }

    public async controlAudio(action: 'play' | 'stop') {
        if (_.isEmpty(this.config.audio)) {
            throw new Error('Audio not found');
        }

        // PLAY
        if (action == 'play' && this.config.isAudioPlaying == false) {
            logger.info('-> Playing audio !');

            // this.playerOptions.filename = path.join(WORKING_DIR, 'public', this.config.audio);
            // this.player.play(this.playerOptions);
            this.config.isAudioPlaying = true;
            this.audioFilePath = path.join(
                WORKING_DIR,
                'public',
                this.config.audio,
            );
            this.playAudio();

            await this.saveConfig();
        }
        // STOP
        else {
            // this.player.stop();
            this.config.isAudioPlaying = false;
            this.stopAudio();

            await this.saveConfig();
        }

        return { isAudioPlaying: this.config.isAudioPlaying };
    }

    public async changeDisplayMode(displayMode: string) {
        this.config.displayMode = displayMode;
        this.saveConfig();

        return this.config;
    }

    // show image using feh with the given image file name
    // tracking the process and killing it when another image is shown
    // or when we switch to play video
    public showImage(image: string) {
        // Check if the env variable has SHOW_IMAGE set to true
        if (process.env.SHOW_IMAGE !== 'true') {
            logger.info(
                '-> [IMAGE] Show image is disabled by environment variable',
            );
            return;
        }

        // If there is an existing image process, kill it
        if (this.imageProcess) {
            execSync('pkill feh');
            this.imageProcess = undefined;
        }

        this.imageProcess = spawn('feh', [
            '-F',
            '--zoom',
            'fill',
            path.join(WORKING_DIR, 'public', image),
        ]);
    }

    // show video using VLC player
    public playVideo(video: string) {
        this.stopVideo();
        this.videoProcess = spawn('vlc', [
            '--fullscreen',
            '--loop',
            path.join(WORKING_DIR, 'public', video),
        ]);
    }

    public stopVideo() {
        try {
            if (this.videoProcess) {
                // On macOS, the VLC process in upper case but on Linux it's lower case
                const killVLCCommand =
                    process.platform === 'darwin' ? 'pkill VLC' : 'pkill vlc';
                execSync(killVLCCommand);
                this.videoProcess = undefined;
            }
        } catch (err) {
            console.error('-> [VIDEO STOP ERROR] ' + err.message);
        }
    }
}
