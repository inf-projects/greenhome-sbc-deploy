import { inject, injectable } from 'inversify';
import _ from 'lodash';
import fs from 'fs-extra';
import path from 'path';
import * as csv from 'fast-csv';

import logger from '../lib/logger';
import { WORKING_DIR } from '../config';
import { Block, Floor, Apartment, Effect, EffectPhase } from '../entities';
import { ControlState, Service, OrderDirection } from '../types';
import { UploadService } from './upload.service';
import { Request } from '../lib/response-composer';
import { ControlService } from './control.service';
import { getManager, MoreThan, LessThan, Not, In } from 'typeorm';
import { FloorService } from './floor.service';
import { EffectService } from './effect.service';

@injectable()
export class BlockService {
    constructor(
        @inject(Service.Upload) private uploadService: UploadService,
        @inject(Service.Floor) private floorService: FloorService,
        @inject(Service.Effect) private effectService: EffectService,
    ) {
        logger.info('[Block service] Construct');
    }

    async getOne(id: number, joinFloors = false) {
        const block = await Block.findOne(
            { id },
            { relations: joinFloors ? ['floors'] : [] },
        );

        if (_.isEmpty(block)) {
            throw new Error('Invalid block id');
        }

        return block;
    }

    async countApartment(id: number) {
        return await Block.countApartments(id);
    }

    public async createBlock() {
        const bottommostBlock = await Block.findBottom();

        const block = new Block();
        block.name = 'New block';
        block.images = [];
        block.state = 'manual';
        block.effects = [];
        block.sortOrder = bottommostBlock ? bottommostBlock.sortOrder + 1 : 0;

        await block.save();
        return block;
    }

    public async createBlockWithFile(req: Request) {
        const { uploadedPath } = await this.uploadService.handleOtherFile(
            req,
            `add_block_`,
        );

        const parseCSV = () =>
            new Promise<any>((resolve) => {
                let floors: any[] = [];

                fs.createReadStream(uploadedPath, { encoding: 'utf8' })
                    .pipe(csv.parse({ headers: false }))
                    .on('error', (error) => console.error(error))
                    .on('data', (row) => {
                        const rowData = _.values(row);
                        const floor = rowData[0];
                        const apartments = [];

                        for (const apartment of rowData.slice(1)) {
                            if (!_.isEmpty(apartment)) {
                                apartments.push(apartment);
                            }
                        }
                        floors.push({
                            name: floor,
                            apartments,
                        });
                    })
                    .on('end', (rowCount: number) => {
                        console.log(`Parsed ${rowCount} rows`);
                        console.log('Total floors:', floors.length);

                        resolve(floors);
                    });
            });

        const floorsData = await parseCSV();

        const bottommostBlock = await Block.findBottom();
        const block = new Block();
        block.name = 'New block';
        block.images = [];
        block.state = 'manual';
        block.effects = [];
        block.sortOrder = bottommostBlock ? bottommostBlock.sortOrder + 1 : 0;

        await block.save();

        // Create floors
        for (const [idx, floorData] of floorsData.entries()) {
            const floor = new Floor();
            floor.name = floorData.name;
            floor.sortOrder = idx;
            floor.block = block;
            floor.images = [];

            await floor.save();

            const apartments: Apartment[] = [];
            for (const [apIdx, apName] of floorData.apartments.entries()) {
                const apartment = new Apartment();

                // [Update 1.2] Apartment name now consists 2 part: name and defined state
                const [name, defined] = apName.split('_');

                apartment.name = name;
                apartment.images = [];
                apartment.state = ControlState.OFF;
                apartment.defined = Number.parseInt(defined) as ControlState;
                apartment.floor = floor;
                apartment.sortOrder = apIdx;

                apartments.push(apartment);
            }

            await Apartment.save(apartments);
        }

        await this.effectService.syncPhaseLength(block.id);

        return block;
    }

    public async getBlocks() {
        const blocks = await Block.find({
            order: {
                sortOrder: 'ASC',
            },
        });

        return await Promise.all(
            blocks.map(async (b) => ({
                ...b,
                apartmentCount: await Block.countApartments(b.id),
            })),
        );
    }

    public async update(
        id: number,
        data: { name?: string; positionX?: number; positionY?: number },
    ) {
        await Block.update({ id }, data);
        return 'UPDATED';
    }

    public async delete(id: number) {
        const currentBlock = await this.getOne(id, true);

        // Delete floor data
        await Promise.all(
            currentBlock.floors.map((floor) =>
                this.floorService.delete(floor.id, false),
            ),
        );

        // Delete effects belong to this block
        const effects = _.filter(
            await this.effectService.getEffects(),
            (effect) => effect.block.id == currentBlock.id,
        );
        for (const effect of effects) {
            await this.effectService.deleteEffect(effect.id);
        }

        await Block.delete({ id: currentBlock.id });

        // Delete floor images
        for (const imagePath of currentBlock.images) {
            await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));
        }

        return 'DONE';
    }

    public async addBlockImage(id: number, req: Request) {
        const block = await this.getOne(id);

        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'block_',
        );
        block.images.push(uploadedPath);
        await block.save();

        return block;
    }

    public async deleteBlockImage(id: number, imagePath: string) {
        const block = await this.getOne(id);

        if (_.indexOf(block.images, imagePath) == -1) {
            throw new Error('Invalid image path / Empty images');
        }

        _.pull(block.images, imagePath);
        await block.save();

        await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));

        return block;
    }

    public async addBlockBackground(id: number, req: Request) {
        const block = await this.getOne(id);

        const uploadedPath = await this.uploadService.handleMediaUpload(
            req,
            'block_bg_',
        );

        if (!_.isEmpty(block.background)) {
            await fs.unlink(path.join(WORKING_DIR, 'public', block.background));
        }

        block.background = uploadedPath;
        await block.save();

        return block;
    }

    public async changeOrder(id: number, direction: OrderDirection) {
        const currentBlock = await this.getOne(id);

        const otherBlock =
            direction == OrderDirection.DOWN
                ? await Block.findBelow(id)
                : await Block.findAbove(id);

        // console.log(currentBlock);
        console.log(otherBlock);

        if (!otherBlock) {
            throw new Error(
                'Block already at the top / bottom. Current sort order: ' +
                    currentBlock.sortOrder,
            );
        }

        logger.warn('Change direction: ' + direction);
        currentBlock.sortOrder += direction;
        otherBlock.sortOrder -= direction;

        await currentBlock.save();
        await otherBlock.save();

        return 'OK';
    }

    public async getBlockEffects(id: number) {
        return await Effect.find({ block: { id } });
    }
}
