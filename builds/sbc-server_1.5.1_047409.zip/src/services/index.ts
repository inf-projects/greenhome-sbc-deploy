import { Container } from 'inversify';

import { Service } from '../types';
import { BlockService } from './block.service';
import { FloorService } from './floor.service';
import { ApartmentService } from './apartment.service';
import { UploadService } from './upload.service';
import { ControlService } from './control.service';
import { SystemService } from './system.service';
import { EffectService } from './effect.service';

export {
    BlockService,
    UploadService,
    FloorService,
    ApartmentService,
    ControlService,
    SystemService,
    EffectService
};

export async function initializeServices(container: Container) {
    container
        .bind<BlockService>(Service.Block)
        .to(BlockService)
        .inSingletonScope();
    container
        .bind<FloorService>(Service.Floor)
        .to(FloorService)
        .inSingletonScope();
    container
        .bind<ApartmentService>(Service.Apartment)
        .to(ApartmentService)
        .inSingletonScope();
    container
        .bind<UploadService>(Service.Upload)
        .to(UploadService)
        .inSingletonScope();
    container
        .bind<ControlService>(Service.Control)
        .to(ControlService)
        .inSingletonScope();
    container
        .bind<SystemService>(Service.System)
        .to(SystemService)
        .inSingletonScope();
    container
        .bind<EffectService>(Service.Effect)
        .to(EffectService)
        .inSingletonScope();
}