import {inject, injectable} from 'inversify';
import fs from 'fs-extra';
import path from 'path';
import formidable from 'formidable';
import _ from 'lodash';
import rimraf from 'rimraf';

import {UPLOAD_DIR, PUBLIC_DIR, MEDIA_DIR} from '../config';
import {Request} from '../lib/response-composer';
import logger from '../lib/logger';

@injectable()
export class UploadService {
    constructor() {
        fs.ensureDir(UPLOAD_DIR);
    }

    private generateForm() {
        const form = new formidable.IncomingForm();
        form.keepExtensions = true;

        return form;
    }

    handleMediaUpload(req: Request, prefix = '') {
        return new Promise<string>(async (resolve, reject) => {
            const mediaPath = path.join(PUBLIC_DIR, MEDIA_DIR);
            const tmpPath = path.join(UPLOAD_DIR);

            logger.info('[Upload] Static path ' + mediaPath);
            logger.info('[Upload] Temp path ' + tmpPath);

            await fs.ensureDir(mediaPath);
            await fs.ensureDir(tmpPath);

            const form = this.generateForm();
            form.parse(req);

            let originalName = '';
            let uploadedPath = '';

            form.on('fileBegin', (name, file) => {
                try {
                    const fileName = `${prefix}${Date.now()}`;
                    const fileExt = path.extname(file.name);

                    originalName = `${fileName}${fileExt}`;

                    uploadedPath = path.join(tmpPath, originalName);
                    file.path = uploadedPath;
                    console.log(file);
                } catch (error) {
                    logger.error('Error 1');
                    reject(error);
                }
            });

            form.on('end', async () => {
                try {
                    logger.info('Uploaded file: ' + uploadedPath);
                    await fs.copy(uploadedPath, path.join(mediaPath, originalName));

                    // Cleanup temporary
                    rimraf(tmpPath, error => {
                        if (!_.isEmpty(error)) {
                            logger.error('[rimraf]', error);
                        }
                    });

                    resolve(`/${MEDIA_DIR}/${originalName}`);
                } catch (error) {
                    logger.error('Upload error: ' + error.message);
                    reject(error);
                }
            });
        });
    }

    handleOtherFile(req: Request, prefix = '') {
        return new Promise<{ blockId: number, uploadedPath: string }>(async (resolve, reject) => {
            const form = this.generateForm();
            form.parse(req);

            let originalName = '';
            let uploadedPath = '';
            let blockId = 0;

            const tmpPath = path.join(UPLOAD_DIR);

            form.on('fileBegin', (name, file) => {
                try {
                    const fileName = `${prefix}${Date.now()}`;
                    const fileExt = path.extname(file.name);

                    originalName = `${fileName}${fileExt}`;

                    uploadedPath = path.join(tmpPath, originalName);
                    file.path = uploadedPath;
                } catch (error) {
                    logger.error('Error 1');
                    reject(error);
                }
            });

            form.on('field', (name, data) => {
                if (name == 'block') {
                    blockId = data;
                }
            })

            form.on('end', async () => {
                try {
                    logger.info('Uploaded file: ' + uploadedPath);
                    resolve({
                        blockId,
                        uploadedPath
                    });
                } catch (error) {
                    logger.error('Upload error: ' + error.message);
                    reject(error);
                }
            });
        });
    }
}
