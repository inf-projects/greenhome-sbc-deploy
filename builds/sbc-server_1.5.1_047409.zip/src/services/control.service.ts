import { inject, injectable, LazyServiceIdentifer } from 'inversify';
import _ from 'lodash';
import SerialPort from 'serialport';
// @ts-ignore
import ReadLine from '@serialport/parser-readline';

import logger from '../lib/logger';
import {
    BLINK_DELAY,
    BLOCK_DATA_OFFSET,
    COMMAND_LENGTH,
    COMMAND_SEND_INTERVAL,
    DEFINED_STATE_UPDATE_INTERVAL,
    EFFECT_UPDATE_INTERVAL,
    SERIAL_PORT,
} from '../config';
import { Apartment, Block, Effect, EffectPhase, Floor } from '../entities';
import { ControlState, Service } from '../types';
import eventEmitter from '../lib/event-emitter';
import { ServiceEvent } from '../events';
import { delay } from '../lib/helper';
import { In, Not } from 'typeorm';
import { SystemService } from './system.service';

@injectable()
export class ControlService {
    serialPort: SerialPort = null;
    parser: any = null;
    effectUpdateTask: NodeJS.Timeout;

    commandQueue: string[] = [];
    commandSenderTask: NodeJS.Timeout;

    blockEffectPhases: {
        [id: number]: {
            effectId: number;
            currentIndex: number;
            deltaTime: number;
            phases: number[][];
        };
    } = {};

    isBlinking = false;

    // Task for auto-blink for the pre-defined state
    definedStateUpdateTask: NodeJS.Timeout;
    definedStateUpdateCounter = 0;
    hasIdle = false;

    constructor(@inject(Service.System) private systemService: SystemService) {
        logger.info('[Control service] Construct');

        eventEmitter.once(ServiceEvent.SERIAL_PORT_OPENED, () => {
            this.effectUpdateTask = setInterval(
                this.effectUpdate.bind(this),
                EFFECT_UPDATE_INTERVAL,
            );
            this.commandSenderTask = setInterval(
                this.commandSender.bind(this),
                COMMAND_SEND_INTERVAL,
            );
            this.definedStateUpdateTask = setInterval(
                this.definedStateUpdate.bind(this),
                DEFINED_STATE_UPDATE_INTERVAL,
            );
            this.restoreState();
        });

        if (SERIAL_PORT) {
            this.initializeSerialPort();
        } else {
            logger.warn('## Serial port unavailable.');
            eventEmitter.emit(ServiceEvent.SERIAL_PORT_OPENED);
        }
    }

    async restoreState() {
        logger.info('[Control service] Restore state');
        const blocks = await Block.find();
        for (const block of blocks) {
            await this.updateBlockState(block.id, ControlState.ON);
            await this.shiftData(block.id);
        }
    }

    private async initializeSerialPort() {
        logger.info('# Current platform: ' + process.platform);
        logger.info('# Serial driver initialization');
        this.serialPort = new SerialPort(
            SERIAL_PORT,
            {
                autoOpen: true,
                baudRate: 115200,
                dataBits: 8,
                parity: 'none',
                stopBits: 1,
            },
            (error) => {
                if (error) {
                    logger.error('Unable to open serial');
                    logger.error(error.message);

                    eventEmitter.emit(ServiceEvent.CRITIAL_ERROR);
                    return;
                }

                logger.info('### Serial Port Opened ###');

                setTimeout(() => {
                    this.parser = new ReadLine();
                    this.serialPort.pipe(this.parser);

                    this.parser.on('data', (line: string) =>
                        console.log(`[MEGA] > ${line}`),
                    );

                    eventEmitter.emit(ServiceEvent.SERIAL_PORT_OPENED);
                }, 2000);
            },
        );
    }

    private async effectUpdate() {
        const blocks = await Block.find();

        for (const block of blocks) {
            if (
                block.state == 'manual' &&
                _.has(this.blockEffectPhases, block.id)
            ) {
                delete this.blockEffectPhases[block.id];
            } else if (block.state == 'auto') {
                // Prepare phase list
                if (
                    !_.has(this.blockEffectPhases, block.id) ||
                    this.blockEffectPhases[block.id].effectId !=
                        block.activeEffectId
                ) {
                    const phases = (
                        await EffectPhase.find({
                            effect: { id: block.activeEffectId },
                        })
                    ).map((p) => p.state);

                    this.blockEffectPhases[block.id] = {
                        effectId: block.activeEffectId,
                        currentIndex: 0,
                        phases,
                        deltaTime: 30000,
                    };
                }

                const activePhase = this.blockEffectPhases[block.id];
                if (activePhase.deltaTime > block.effectSpeed) {
                    activePhase.deltaTime = 0;

                    await this.shiftData(block.id);

                    // Move to next phase of effect
                    activePhase.currentIndex =
                        (activePhase.currentIndex + 1) %
                        activePhase.phases.length;
                }

                activePhase.deltaTime += EFFECT_UPDATE_INTERVAL;
            }
        }
    }

    private async commandSender() {
        if (!_.isEmpty(this.commandQueue)) {
            const command = this.commandQueue.shift();

            if (this.serialPort) {
                this.serialPort.write(command, 'hex');
                await delay(20);
            }
        }
    }

    private async definedStateUpdate() {
        // Stop blink if the counter > IDLE_TIMEOUT ~ default 5 minutes
        const idleTime = parseInt(process.env.IDLE_TIMEOUT || '300');

        if (
            this.definedStateUpdateCounter >
            idleTime * DEFINED_STATE_UPDATE_INTERVAL
        ) {
            await this.startIdle();
            return;
        }

        const blocks = await Block.find();
        let shouldShift = false;
        const apartmentsToUpdate = [];

        for (const block of blocks) {
            const floors = await Floor.find({ block: { id: block.id } });
            shouldShift = false;

            const apartments = await Apartment.find({
                where: {
                    floor: { id: In(floors.map((f) => f.id)) }, // Use In for multiple floor IDs
                    activated: true,
                },
            });

            if (apartments.length == 0) {
                continue;
            }

            // in each apartment, if the defined state is auto, then change the state
            for (const apartment of apartments) {
                if (
                    apartment.activated &&
                    apartment.defined === ControlState.AUTO
                ) {
                    apartment.state =
                        apartment.state === ControlState.OFF
                            ? ControlState.ON
                            : ControlState.OFF;
                    apartmentsToUpdate.push(apartment);
                    shouldShift = true;
                }
            }

            if (shouldShift) {
                await Apartment.save(apartmentsToUpdate);
                apartmentsToUpdate.length = 0;
                await this.shiftData(block.id);
            }
        }

        // Update counter
        this.definedStateUpdateCounter += DEFINED_STATE_UPDATE_INTERVAL;
        this.hasIdle = false;

        // Stop video if any
        this.systemService.stopVideo();
    }

    public async startBlockEffect(id: number, effectId: number) {
        const block = await Block.findOne({ id });

        if (_.isEmpty(block)) {
            throw new Error('Invalid block id');
        }

        if (block.state == 'auto' && block.activeEffectId == effectId) {
            return 'NOTHING TO UPDATE';
        }

        const effect = await Effect.findOne({ id: effectId });
        if (_.isEmpty(effect)) {
            throw new Error('Invalid effect id');
        }

        block.state = 'auto';
        block.activeEffectId = effectId;
        await block.save();

        return 'OK';
    }

    public async updateBlockState(id: number, state: ControlState) {
        if (this.isBlinking) {
            return 'Running blinking effect';
        }

        const block = await Block.findOne({ id });

        if (_.isEmpty(block)) {
            throw new Error('Invalid block id');
        }

        if (block.state != 'manual') {
            block.state = 'manual';
            await block.save();
        }

        const floors = await Floor.find({ block: { id } });

        if (process.env.BLINK == 'true' && state == ControlState.ON) {
            this.isBlinking = true;
            for (let i = 1; i <= 4; i++) {
                await Apartment.update(
                    {
                        where: floors.map((f) => ({ floor: { id: f.id } })),
                    } as any,
                    { state: i % 2 },
                );

                await this.shiftData(block.id);
                await delay(BLINK_DELAY);
            }

            this.isBlinking = false;
        }

        // Turn on single floor
        if (state === ControlState.ON) {
            await Apartment.update(
                {
                    where: {
                        floor: { id: In(floors.map((f) => f.id)) },
                        defined: Not(ControlState.OFF),
                    },
                } as any,
                { state: ControlState.ON, activated: false },
            );
        } else {
            await Apartment.update(
                {
                    where: {
                        floor: { id: In(floors.map((f) => f.id)) },
                    },
                } as any,
                { state: ControlState.OFF, activated: false },
            );
        }

        await this.shiftData(block.id);

        // Stop idle if it's running
        await this.stopIdle();

        return 'OK';
    }

    public async updateFloorState(id: number, state: ControlState) {
        if (this.isBlinking) {
            return 'Running blinking effect';
        }

        const floor = await Floor.findOne({ id }, { relations: ['block'] });

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        if (process.env.BLINK == 'true' && state == ControlState.ON) {
            this.isBlinking = true;
            for (let i = 1; i <= 4; i++) {
                await Apartment.update({ floor: { id } }, { state: i % 2 });

                await this.shiftData(floor.block.id);
                await delay(BLINK_DELAY);
            }

            this.isBlinking = false;
        }

        // Turn off a whole block
        await this.updateBlockState(floor.block.id, ControlState.OFF);

        // Turn on selected floor
        await Apartment.update(
            { floor: { id }, defined: Not(ControlState.OFF) },
            { state: ControlState.ON, activated: true },
        );

        await this.shiftData(floor.block.id);

        // Stop idle if it's running
        await this.stopIdle();

        return 'OK';
    }

    public async updateApartmentState(id: number, state: ControlState) {
        if (this.isBlinking) {
            return 'Running blinking effect';
        }

        const apartment = await Apartment.findOne(
            { id },
            { relations: ['floor'] },
        );

        if (_.isEmpty(apartment)) {
            throw new Error('Invalid apartment id');
        }

        const floor = await Floor.findOne(
            { id: apartment.floor.id },
            { relations: ['block'] },
        );

        // Apply blinking effect when turn the apartment on / off
        // DEFAULT is OFF
        if (process.env.BLINK == 'true' && state == ControlState.ON) {
            this.isBlinking = true;
            for (let i = 1; i <= 4; i++) {
                apartment.state = i % 2;
                await apartment.save();

                await this.shiftData(floor.block.id);
                await delay(BLINK_DELAY);
            }

            this.isBlinking = false;
        }

        // Turn off a whole block if a apartment is on
        await this.updateBlockState(floor.block.id, ControlState.OFF);

        // De-active all other apartments
        const floors = await Floor.find({ block: { id: floor.block.id } });
        await Apartment.update(
            {
                where: floors.map((f) => ({ floor: { id: f.id } })),
            } as any,
            { activated: false },
        );

        // Turn on single apartment
        apartment.state = apartment.defined || ControlState.OFF;
        apartment.activated = true;
        await apartment.save();

        await this.shiftData(floor.block.id);

        // Stop idle if it's running
        await this.stopIdle();

        return 'OK';
    }

    async shiftData(blockId: number, overrideSpecialEffect = false) {
        if (overrideSpecialEffect) {
            const specialSignal = ['FF', 'FF'];
            const controlCommand =
                specialSignal.join('') +
                _.repeat('00', COMMAND_LENGTH - specialSignal.length);

            logger.info('[CMD]: ' + controlCommand);
            this.commandQueue.push(controlCommand);

            return;
        }

        const block = await Block.findOne({ id: blockId });
        let data: number[] = [];
        let isSpecialEffect = 0;

        if (block.state == 'manual') {
            const apartments = await Block.findApartments(blockId);
            data = apartments.map((a) => _.clamp(a.state, 1));
        } else {
            const activePhase = this.blockEffectPhases[blockId];
            isSpecialEffect = activePhase.phases[activePhase.currentIndex][0];
            data = _.slice(activePhase.phases[activePhase.currentIndex], 1);
        }

        const packages = _.chunk(data, 8).map((chunk) =>
            _.padStart(
                parseInt(_.padEnd(chunk.join(''), 8, '0'), 2).toString(16),
                2,
                '0',
            ),
        );

        const controlCommand =
            [
                _.padStart(block.output.toString(16), 2, '0'),
                _.padStart((+isSpecialEffect).toString(16), 2, '0'),
                _.padStart(packages.length.toString(16), 2, '0'),
                ...packages,
            ].join('') +
            _.repeat(
                '00',
                COMMAND_LENGTH - packages.length - BLOCK_DATA_OFFSET,
            );

        logger.info('[CMD]: ' + controlCommand);
        this.commandQueue.push(controlCommand);
    }

    public async startIdle() {
        if (!this.hasIdle) {
            console.log('-> [IDLE] Stop shifting data');
            await this.shiftData(0, true);
            this.hasIdle = true;

            // Play idle video
            if (this.systemService.config.idleVideo) {
                this.systemService.playVideo(
                    this.systemService.config.idleVideo,
                );
            } else {
                logger.warn('-> [ERROR] No idle video configured');
            }
        }
    }

    public async stopIdle() {
        if (this.hasIdle) {
            console.log('-> [IDLE] Start shifting data');
            this.hasIdle = false;

            // Stop video if any
            this.systemService.stopVideo();

            // Reset counter
            this.definedStateUpdateCounter = 0;
        }
    }
}
