import { inject, injectable } from 'inversify';
import _ from 'lodash';
import fs from 'fs-extra';
import path from 'path';

import logger from '../lib/logger';
import { WORKING_DIR } from '../config';
import { Block, Floor, Apartment } from '../entities';
import { ControlState, Service, OrderDirection } from '../types';
import { UploadService } from './upload.service';
import { Request } from '../lib/response-composer';
import { getManager, In } from 'typeorm';
import { ApartmentService } from './apartment.service';
import { EffectService } from './effect.service';

@injectable()
export class FloorService {
    constructor(
        @inject(Service.Upload) private uploadService: UploadService,
        @inject(Service.Apartment) private apartmentService: ApartmentService,
        @inject(Service.Effect) private effectService: EffectService
    ) {
        logger.info('[Floor service] Construct');
    }

    async getOne(id: number, joinApartments = false) {
        const floor = await Floor.findOne(
            { id },
            { relations: joinApartments ? ['apartments'] : [] }
        );

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        return floor;
    }

    public getByBlockId(blockId: number) {
        return Floor.findByBlock(blockId);
    }

    public async addFloor(blockId: number) {
        const block = await Block.findOne({ id: blockId });

        if (_.isEmpty(block)) {
            throw new Error("Invalid block id");
        }

        const bottomostFloor = await Floor.findBottom(blockId);

        const floor = new Floor();
        floor.name = 'New floor';
        floor.images = [];
        floor.block = block;
        floor.sortOrder = bottomostFloor ? bottomostFloor.sortOrder + 1 : 0;
        await floor.save();

        await this.effectService.syncPhaseLength(block.id);

        return floor;
    }

    public async editName(id: number, name: string) {
        const floor = await Floor.findOne({ id });
        
        if (_.isEmpty(floor)) {
            throw new Error("Invalid floor id");
        }

        floor.name = name;
        await floor.save();

        return floor;
    }

    public async delete(id: number, shouldUpdateEffect = false) {
        const currentFloor = await Floor.findOne({ id }, { relations: ['block', 'apartments'] });

        await Promise.all(
            currentFloor.apartments.map(
                apartment => this.apartmentService.delete(apartment.id, false)
            )
        );

        await Floor.delete({ id: currentFloor.id });

        // Delete floor images
        for (const imagePath of currentFloor.images) {
            await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));
        }

        // Update block effect size
        if (shouldUpdateEffect) {
            await this.effectService.syncPhaseLength(currentFloor.block.id);
        }

        return 'DONE';
    }

    public async addFloorImage(id: number, req: Request) {
        const floor = await Floor.findOne({ id });

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        const uploadedPath = await this.uploadService.handleMediaUpload(req, 'floor_');
        floor.images.push(uploadedPath);
        await floor.save();

        return floor;
    }

    public async deleteFloorImage(id: number, imagePath: string) {
        const floor = await Floor.findOne({ id });

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        if (_.indexOf(floor.images, imagePath) == -1) {
            throw new Error('Invalid image path / Empty images');
        }

        _.pull(floor.images, imagePath);
        await floor.save();

        await fs.unlink(path.join(WORKING_DIR, 'public', imagePath));

        return floor;
    }

    public async addFloorBackground(id: number, req: Request) {
        const floor = await Floor.findOne({ id });

        if (_.isEmpty(floor)) {
            throw new Error('Invalid floor id');
        }

        const uploadedPath = await this.uploadService.handleMediaUpload(req, 'floor_bg_');

        if (!_.isEmpty(floor.background)) {
            await fs.unlink(path.join(WORKING_DIR, 'public', floor.background));
        }

        floor.background = uploadedPath;
        await floor.save();

        return floor;
    }

    public async changeOrder(id: number, direction: OrderDirection) {
        const currentFloor = await this.getOne(id, false);

        const otherFloor = direction == OrderDirection.DOWN
            ? await Floor.findBelow(id)
            : await Floor.findAbove(id)

        if (!otherFloor) {
            throw new Error('Floor already at the top / bottom. Current sort order: ' + currentFloor.sortOrder);
        }

        logger.warn('Change direction: ' + direction);
        currentFloor.sortOrder += direction;
        otherFloor.sortOrder -= direction;

        await currentFloor.save();
        await otherFloor.save();

        return 'OK';
    }
}
