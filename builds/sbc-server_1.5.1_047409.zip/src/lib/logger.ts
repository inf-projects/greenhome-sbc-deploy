import * as winston from 'winston';
import { IS_PRODUCTION, IS_TEST } from '../config';

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        new winston.transports.File({ filename: './log/error.log', level: 'error' }),
        new winston.transports.File({ filename: './log/combined.log' })
    ]
});

if (!IS_PRODUCTION && !IS_TEST) {
    logger.add(new winston.transports.Console({
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
        )
    }));
}

class MorganStream {
    write(text: string) {
        logger.info(text);
    }
}
export const morganStream = new MorganStream();
export default logger;